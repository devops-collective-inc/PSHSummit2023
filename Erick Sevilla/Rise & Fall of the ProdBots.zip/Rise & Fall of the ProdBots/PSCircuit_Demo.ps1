# PSCircuit Demo
# open /Users/ericksevilla/.local/share/powershell/Modules/PSCircuit/1.0.1        
Install-Module PSCircuit -Force -Verbose    
Import-Module PSCircuit  -Force -Verbose

$ClientID     = '42b8a297f60f42569fcd876df25d69bd'
$ClientSecret = Get-Secret -Name PSCircuitSecret -AsPlainText
$Token        = (Request-CircuitToken -ClientID $ClientID -ClientSecret $ClientSecret).access_token
$ConvId       = (Get-CircuitConversations -Token $Token).convId[0]
$Title        = 'Fist Bump!' # Title for new Circuit Item, replace this
$Message      = 'Balalala' # Message you want delivered, replace this
$attachment   = './Downloads/Testfile.txt'

Send-CircuitMessage     -Token $Token -ConversationID $ConvId -Title $Title -Message $Message
Send-CircuitAttachment  -Token $Token -ConversationID $ConvId -FilePath $attachment
Start-CircuitProdBot    -Token $Token -ConversationID $ConvId
