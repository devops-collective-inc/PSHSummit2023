# Install-Module Microsoft.PowerShell.ConsoleGuiTools

function Get-RandomColor {
    $colors = [enum]::GetValues([System.ConsoleColor])
    $randomColor = Get-Random -InputObject $colors
    return $randomColor
}

while ($true) {
    $randomColor = Get-RandomColor
    Write-Host "Save the kittens!" -ForegroundColor $randomColor
    Start-Sleep -Milliseconds 500
}

function Get-HighMemoryProcesses {
    [CmdletBinding()]
    param ( [Parameter(Mandatory=$true)][int64]$MemoryThresholdKB)
    Get-Process | Where-Object { ($_.WorkingSet64 / 1KB) -gt $MemoryThresholdKB }
}

Get-HighMemoryProcesses -MemoryThresholdKB 100000

# Mac OSX sample 1
$Button_osascript = (osascript -e 'tell app "System Events" ¬
                    to display dialog "Here. Take a cookie."')
if ($Button_osascript)  {osascript -e 'tell app "System Events" ¬
                                       to display alert "You feel better!"'}
if (!$Button_osascript) {osascript -e 'tell app "System Events" ¬
                                       to display alert "Nothing changed!"'}
# Mac OSX sample 2
$Button_appleScript =   (('display alert "Here. Take a cookie." ¬
                message "I promise, by the time you are done eating it, you will feel right as rain." ¬
                buttons { "Om nom nom!", "Nah" }' | osascript -s s) -split '"')[1]
if ($Button_appleScript -eq 'Om nom nom!') {'display alert "Feeling better already!"' | osascript -s s }
if ($Button_appleScript -eq 'Nah'        ) {'display alert "Remember there is no spoon"' | osascript -s s }
