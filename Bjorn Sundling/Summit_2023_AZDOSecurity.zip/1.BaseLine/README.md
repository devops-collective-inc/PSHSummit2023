# Baseline Setup

This repo fits quite well to how we normaly do stuff.

The contents of the repo are

- PowerShell module, AwesomeModule\AwesomeModule.ps*1
- BuildScript, AwesomeModule.Build.ps1
- Tests, tests\AwesomeModule.Tests.ps1
- Pipeline yaml, AwesomeModule.yaml
  - Triggers on main
  - Runs tests
  - Runs build script
  - Publishes built module to storage blob in azure
- Verification yaml, AwesomeModule.Verify.yaml
  - Triggers on PR
  - Runs tests.
