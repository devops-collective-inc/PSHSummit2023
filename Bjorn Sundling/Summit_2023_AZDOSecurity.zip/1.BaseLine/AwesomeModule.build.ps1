Write-Host "I'm building a module!"
Remove-Item "$PSScriptRoot\bin" -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item "$PSScriptRoot\AwesomeModule" -Destination "$PSScriptRoot\bin" -Recurse -Force