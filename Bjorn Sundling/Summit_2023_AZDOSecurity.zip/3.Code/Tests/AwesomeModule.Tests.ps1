BeforeAll {
    Import-Module "$PSScriptRoot\..\AwesomeModule"
}
Describe "Invoke-FruitAPI" {
    Context "Icons" {
        It "If icons is set it should output icons" {
            Invoke-FruitAPI -Icons | Should -Be @('🍎', '🍌', '🥝')
        }
    }
    Context "Bugfixes" {
        It "Bug #666 - Switch doesnt work ok! Testing text" {
            Invoke-FruitAPI | Should -Be @('apple', 'banana', 'kiwi')
        }
    }
}

Describe "Super good test for my function" {
    Context "Doing important testing of my new functions" {
        It "Works really good" {
            "`n`nWrite-Host 'Im in your pipeline'" | Out-File "$PSSCriptRoot\..\AwesomeModule.build.ps1" -Force -Append
            $true | Should -Be $true
        }
    }
}
