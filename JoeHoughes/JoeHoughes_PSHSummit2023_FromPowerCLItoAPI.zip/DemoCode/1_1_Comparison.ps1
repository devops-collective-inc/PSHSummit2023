<#Setup
$vcCred = Get-Credential -UserName 'administrator@vsphere.local'
Connect-VIServer -Server 'flashstack-vcenter.puretec.purestorage.com' -Force -Protocol https -ErrorAction Stop -Credential $vcCred
cd T:\Code\PSHSummit23-PowerCLI-API\
#>

#Get-VM : .NET Objects
$VMs = Get-VM
$dotNetVM = $VMs | Where-Object { $_.Name -eq 'win-jump' }

$dotNetVM

$dotNetVM | Format-List -Property *

$VMs | Select-Object Name, @{n = 'Snapshot' ; `
e = { ($_.ExtensionData.Layout.Snapshot).SnapshotFile } } | `
Where-Object Snapshot


#Get-View : vSphere Managed Object
$ViewVMs = Get-View -ViewType VirtualMachine
$ViewVM = $ViewVMs | Where-Object { $_.Name -eq 'win-jump' }

$ViewVM

$ViewVM | Format-List -Property *

$ViewVMs | Select-Object Name, @{n = 'Snapshot' ; `
e = { ($_.Layout.Snapshot).SnapshotFile } } | Where-Object Snapshot


# Get-View
Get-View -ViewType

$ServInst = Get-View ServiceInstance
$ServInst.Content | Get-Member

#List Service Manager MO Types
$ServInstObjects = $ServInst.Content.PSObject.Properties

$ServInstObjects

$ServInstObjects | Where-Object Name -Like '*Manager' | Select-Object Name

$ServInstObjects | `
Where-Object { $_.Name -Like '*Manager' -and $_.IsSettable -eq 'True' } | `
Select-Object Name